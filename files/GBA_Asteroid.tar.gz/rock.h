#ifndef ROCK_BITMAP_H
#define ROCK_BITMAP_H
extern const unsigned short rock[800];
#define ROCK_WIDTH 40
#define ROCK_HEIGHT 20
#endif