#ifndef SHIP_BITMAP_H
#define SHIP_BITMAP_H
extern const unsigned short ship[1024];
#define SHIP_WIDTH 32
#define SHIP_HEIGHT 32
#endif