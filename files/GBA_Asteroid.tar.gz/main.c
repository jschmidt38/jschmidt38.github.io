#include <stdlib.h>
#include <stdio.h>

#include "myLib.h"
#include "text.h"
#include "ship.h"
#include "rock.h"
#include "title.h"
#include "ending.h"

//int NUMOBJS = 12;

enum GBAState {
	PRESTART,
	START, //intro screen
	START_NODRAW,
	BATTLEREADY,
	BATTLE,
	GAMEOVER
	// TODO add more states here!
};
volatile short frame = 0;

volatile short hit = 0;


int main()
{
	REG_DISPCTL = MODE3 | BG2_ENABLE;

	//MOVOBJ objs[NUMOBJS];
	//MOVOBJ oldobjs[NUMOBJS];
	//MOVOBJ *cur;
//void drawImage3(60,40,16,16,SHIP_data);
	enum GBAState state = PRESTART;
	//enum GBAState wasState = START;

	while(1) {
		waitForVblank();
		if (KEY_DOWN_NOW(BUTTON_SELECT)){
			state = PRESTART;
			drawRect(0,0,180,240,BLACK);
		}
		else{
		switch(state) {
			case PRESTART:
			drawImage3(0,0,TITLE_WIDTH,TITLE_HEIGHT,title);
			delay(40);
			state = START;
			drawRect(0,0,180,240,BLACK);
			break;
		case START:
			frame = 0;
			drawString(20, 40, "WELCOME TO ASTEROID DODGER", RED);
			drawImage3(60,40,SHIP_WIDTH,SHIP_HEIGHT,ship);
			drawString(100, 40, "Press A for the next one", BLUE);
			drawString(120, 40, "In vbam, A is probably", LTGRAY);
			drawString(130, 50, "Mapped to the Z key", LTGRAY);
			state = START_NODRAW;
		break;

		case START_NODRAW:
			if(KEY_DOWN_NOW(BUTTON_A)){
				state = BATTLEREADY;
				drawRect(0,0,180,240,BLACK);
				
				break;
			}
			state = START_NODRAW;
		break;

		case BATTLEREADY:
		score = 0;
		init_rocks();
		init_ship();

		state = BATTLE;
		break;

		case BATTLE:
		//initialize

			frame++;
			


			if ((frame - 4) == 0) {
				frame = 0;
				//move rocks and ship here then check for collisions
				moveRocks();
				movePlayer();
				hit = checkCollisions();//collisions with player
				if(hit) {
					state = GAMEOVER;
					break;
				}
				checkScore();//collisions with bottom of screen and rock
				frame = 0;
				
			}
		break;

		case GAMEOVER:
		drawImage3(0,0,ENDING_WIDTH,ENDING_HEIGHT,ending);

		break;



		}









	}
	}
	return 0;
}
//object is to fly through astroid belt
// player is able to dodge with up down left right
//player will be 5x3 
//objects avoided are by moving around
//points go up as asteroids leave screen and character is not dead
