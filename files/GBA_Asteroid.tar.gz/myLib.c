

#include "myLib.h"
#include "text.h"
//#include "font.h"
#include "ship.h"
#include "rock.h"
#include <stdio.h>
#include <stdlib.h>
#include "title.h"
#include "ending.h"


unsigned short *videoBuffer = VIDEOBUFFERADDRESS;
char buffer[50];

void setPixel(int r, int c, unsigned short color)
{
	videoBuffer[OFFSET(r, c, 240)] = color;
}

void drawRect(int row, int col, int h, int w, unsigned short color)
{
	int r;
	for(r=0; r<h; r++)
	{
		DMA[3].src = &color;
		DMA[3].dst = videoBuffer +OFFSET(row+r, col, 240);
		DMA[3].cnt = w | DMA_ON | DMA_SOURCE_FIXED;
	}
}


/* Note: Once we implement waitForVblank we no longer need this function
*/
void delay(int n)
{
	volatile int x = 0;
	int i;
	for(i=0; i<10000*n; i++)
	{
		x = x + 1;
	}
}

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

void boundsCheck(int *value, int bound, int *delta, int ckscore, int *score)
{

	if(*value<0)
	{
		*value = 0;
		*delta = -*delta;
		if(ckscore)
		{
			*score = *score + 1;
		}
	}
	if(*value>bound)
	{
		*value = bound;
		*delta = -*delta;
	}
	
}


void drawImage3(int r, int c, int width, int height, const u16* image) {
	for (int x = 0; x < height; x++) {
		DMA[3].src = &image[OFFSET(x, 0, width)];
		DMA[3].dst = &videoBuffer[OFFSET(r + x, c, 240)];
		DMA[3].cnt = (width) | DMA_ON;
	}
}

void clearScreen(unsigned short color)
	 	{
	 		drawRect(0,0,240,160,color);
	 	}
	
    
void init_rocks() {
	for (int i =0; i<ROCKLIMIT;i++) {
		rocks[i].alive = rand() % 4;
		rocks[i].c = (rand() % 180) + 10;
		rocks[i].width = ROCK_WIDTH;
		rocks[i].height = ROCK_HEIGHT;
		if(rocks[i].alive == 0) { //if 0, the rock is present
			rocks[i].r = rand() % 10;
			drawImage3(rocks[i].r,rocks[i].c,rocks[i].width,rocks[i].height,rock);
		}
		else{
			rocks[i].r = 0;
		}

	}

}


void init_ship() {
	player.r = 110;
	player.c = 100;
	player.width = SHIP_WIDTH;
	player.height = SHIP_HEIGHT;
	drawImage3(player.r,player.c,player.width,player.height,ship);

}


void moveRocks() {
	for(int i =0;i<ROCKLIMIT;i++){
		if(rocks[i].alive ==0) {
			drawRect(rocks[i].r,rocks[i].c,rocks[i].height,rocks[i].width,BLACK);
			rocks[i].r = rocks[i].r + 1;
			drawImage3(rocks[i].r,rocks[i].c,rocks[i].width,rocks[i].height,rock);

		}
		else {
			rocks[i].alive--;
		}
	}
}


void movePlayer(){
		drawRect(player.r,player.c,player.width,player.height,BLACK);
		if(KEY_DOWN_NOW(BUTTON_UP)){
				if (player.r > 20) {
					player.r = player.r - 5;
				}
			}
		if(KEY_DOWN_NOW(BUTTON_DOWN)){
				if(player.r <110) {
					player.r = player.r + 5;
				}
				
			}
		if(KEY_DOWN_NOW(BUTTON_LEFT)){
				if (player.c > LOWER){
					player.c = player.c - 5;
				}
		
			}
		if(KEY_DOWN_NOW(BUTTON_RIGHT)){
				if (player.c < UPPER){
					player.c = player.c + 5;
				}
			}
		
		drawImage3(player.r,player.c,player.width,player.height,ship);
	

}


void checkScore(){
	for(int i = 0; i < ROCKLIMIT; i++){
		if (rocks[i].r > 110) {
			score++;
			drawRect(rocks[i].r,rocks[i].c,rocks[i].height,rocks[i].width,BLACK);
			rocks[i].alive = rand() % 4;
			rocks[i].r =4;
			rocks[i].c = (rand() % 180) + 10;

		}
		drawRect(140,10,20,100,BLACK);
		sprintf(buffer,"Score: %d",score);
		drawString(150,10,buffer,BLUE);
	}
}//collisions with bottom of screen and rock


short checkCollisions() {
	for (int i = 0; i < ROCKLIMIT; i++){
		if(rocks[i].alive == 0) {
			if (((rocks[i].c + rocks[i].width) >= player.c) && (rocks[i].c <= (player.c + player.width))) {
				//rock on right side of player
				// if right edge of rock is farther right than left corner of ship
				//and left corner of rock is farther left than right corner of ship
				if((rocks[i].r >= player.r) && ((rocks[i].r <= player.r + player.height))){
					//rock on bottom
					//top of rock is below top of ship
					//top of rock is above bottom of ship
					return 1;
				}
				else if((rocks[i].r+rocks[i].height >= player.r)&&((rocks[i].r+rocks[i].height) <= player.r + player.height)) {
					//rock on top
					//bottom of rock is below ship top
					//bottom of rock is is above bottom of ship
					return 1;
				}
			}
			


		}
	}
	return 0;
}