#ifndef ENDING_BITMAP_H
#define ENDING_BITMAP_H
extern const unsigned short ending[38400];
#define ENDING_WIDTH 240
#define ENDING_HEIGHT 160
#endif