﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Pong_ReDemo.Components;
using System;

namespace Pong_ReDemo
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class PongNew : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Bar player;
        Bar computer;
        Ball ball;
        InputManager input;
        BallManager ballManage;
        CollisionManager collisionManage;
        ScoreManager scoreManage;
        BackgroundObj background;
        bool fullscreen;

        public PongNew()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            fullscreen = false;
            if (fullscreen)
            {
                if (!graphics.IsFullScreen)
                {
                    graphics.ToggleFullScreen();
                }
            }
        }


        protected override void Initialize()
        {

            base.Initialize();
            
            
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            int width = graphics.GraphicsDevice.Viewport.Width;
            int height = graphics.GraphicsDevice.Viewport.Height;
            
                //initialize player
                player = new Bar(true, width, height, 0);
                player.setSprite(this.Content.Load<Texture2D>(player.getAssetName()));
                player.setSpriteBatch(spriteBatch);

                //initialize computer
                computer = new Bar(false, width, height, 1);
                computer.setSprite(this.Content.Load<Texture2D>(computer.getAssetName()));
                computer.setSpriteBatch(spriteBatch);
           
                //initialize ball
                ball = new Ball(height,width);
                ball.setSprite(this.Content.Load<Texture2D>(ball.getAssetName()));
                ball.setSpriteBatch(spriteBatch);



            input = new InputManager(player, computer, height, width, ball); //initialize inputmanager

            ballManage = new BallManager(height, width);

            collisionManage = new CollisionManager();

            scoreManage = new ScoreManager(true, height,width);
            scoreManage.setSpriteFont(this.Content.Load<SpriteFont>(scoreManage.getAssetName()));
            scoreManage.setSpriteBatch(spriteBatch);

            background = new BackgroundObj(width);
            background.setSprite(this.Content.Load<Texture2D>(background.getAssetName()));
            background.setSpriteBatch(spriteBatch);



            // TODO: use this.Content to load your game content here
        }

        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (IsActive)
            {
                KeyboardState state = Keyboard.GetState();
                if (state.IsKeyDown(Keys.Escape))
                    Exit();
                input.manage(state);
                ballManage.manage(ball);
                collisionManage.manage(player, computer, ball);
                if (ball.speed.X == 0) {
                    scoreManage.manage(ball);
                    }

                if (!scoreManage.gameActive()) {
                    input.reset(state,scoreManage,ball,player,computer);
                }


                base.Update(gameTime);
            }
        }

        protected override void OnActivated(object sender, EventArgs args)
        {
            Window.Title = "Pong";
            base.OnActivated(sender, args);
        }

        protected override void OnDeactivated(object sender, EventArgs args)
        {
            Window.Title = "(Paused) Pong";
            base.OnDeactivated(sender, args);
        }
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            background.draw();
            player.draw();
            computer.draw();
            ball.draw();
            scoreManage.draw();

            spriteBatch.End();
            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
