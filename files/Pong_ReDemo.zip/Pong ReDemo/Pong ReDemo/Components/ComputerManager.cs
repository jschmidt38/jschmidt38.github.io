﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class ComputerManager
    {
        Bar bar;
        private int height;
        private int width;
        Ball ball;
        private int limit;
        private int speed; //speed of the paddle

        public ComputerManager(Bar bar1, int hei, int wid, Ball ball1) {
            bar = bar1;
            height = hei;
            ball = ball1;
            width = wid;
            limit = 64; //this is the size of the bar on top
            speed = 8;
        }

        public void manage(Ball ball1)
        {
            if (ball1 != null)
                ball = ball1;
            {
                if (ball.speed.X > 0 && ball.position.X > width / 3 * 2)
                {
                    if (ball.bottom - bar.getSprite().Height / 2 > bar.position.Y)
                    {

                        bar.position.Y += speed;
                        if (bar.position.Y + bar.getSprite().Height > height - 4)
                        {
                            bar.position.Y = height - bar.getSprite().Height;
                        }
                    }
                    //move computer up
                    if (ball.position.Y + bar.getSprite().Height / 2 < bar.position.Y + bar.getSprite().Height)
                    {
                        bar.position.Y += (-1 * speed);
                        if (bar.position.Y < limit + 5)
                            bar.position.Y = limit;
                    }
                }

            }
        }
    }
}