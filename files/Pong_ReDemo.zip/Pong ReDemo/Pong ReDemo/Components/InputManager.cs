﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class InputManager
    {
        Bar first;
        Bar second;
        private int height;
        private int width;
        private bool isHuman1;
        private bool isHuman2;
        ComputerManager comp1;
        ComputerManager comp2;
        Ball ball;

        public InputManager(Bar bar1, Bar bar2, int hei, int wid, Ball ball1)
        {
            first = bar1;
            second = bar2;
            height = hei;
            width = wid;
            isHuman1 = bar1.isHuman();
            isHuman2 = bar2.isHuman();

            if (!isHuman1) {
                comp1 = new ComputerManager(first, height, width, ball);
            }

            if (!isHuman2)
            {
                comp2 = new ComputerManager(second, height, width, ball);
            }
            ball = ball1;

        }

        public void manage(KeyboardState state)
        {
            //Handle the first bar
            if (isHuman1)
            {
                if (state.IsKeyDown(Keys.W))
                { //down
                    if (first.position.Y - 72 > 0)
                    {
                        first.position.Y -= 8;
                    }
                    else
                    {
                        first.position.Y = 64;
                    }

                }
                if (state.IsKeyDown(Keys.S))
                { //up
                    if (first.position.Y + 8 + first.getSprite().Height < height)
                    {
                        first.position.Y += 8;
                    }
                    else
                    {
                        first.position.Y = height - first.getSprite().Height;
                    }
                }
            }
            else {
                    comp1.manage(ball);
            }


            //Handle the second bar
            if (isHuman2)
            {
                if (state.IsKeyDown(Keys.Up))
                { //down
                    if (second.position.Y - 72 > 0)
                    {
                        second.position.Y -= 8;
                    }
                    else
                    {
                        second.position.Y = 64;
                    }

                }
                if (state.IsKeyDown(Keys.Down))
                { //up
                    if (second.position.Y + 8 + second.getSprite().Height < height)
                    {
                        second.position.Y += 8;
                    }
                    else
                    {
                        second.position.Y = height - second.getSprite().Height;
                    }
                }
            }
            else {
                     comp2.manage(ball);
            }

        }

        public void reset(KeyboardState state, ScoreManager scoreboard, Ball ball, Bar bar1, Bar bar2)
        {
            if (state.IsKeyDown(Keys.Enter)) { 
            scoreboard.reset();
            ball.reset();
            bar1.reset();
            bar2.reset();
        }

        }
    }
}