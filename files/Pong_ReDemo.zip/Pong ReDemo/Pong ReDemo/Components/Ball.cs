﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class Ball
    {

        public Vector2 position; //also holds the left and top
        private const string assetName = "ball";
        private Texture2D texture;
        private SpriteBatch batch;
        public Vector2 speed;
        public int bottom; //dimension of the ball y + texture length
        public int right; // dimension of the ball x + texture width
        private int height;
        private int width;



        public Ball(int height1, int width1)
        {
            height = height1;
            width = width1;
            position = new Vector2(height/3 * 2, width / 2);
            Random rand = new Random();
            int x = rand.Next(3,5) ;
            int ydir = rand.Next(0, 1);
            int yspeed = rand.Next(1, 5);
            if (ydir == 0) {
                ydir -= 1;
            }
            
            yspeed = yspeed * ydir;
            speed = new Vector2(x, yspeed);
            bottom = (int)position.Y + 3;
            right = (int)position.X + 3; 
        }

        public string getAssetName()
        {
            return assetName;
        }

        public void setSprite(Texture2D x)
        {
            texture = x;
            bottom = (int) position.Y + (int) texture.Height;
            right = (int)position.X + (int)texture.Width;
        }

        public Texture2D getSprite()
        {
            return texture;
        }

        public void setSpriteBatch(SpriteBatch x)
        {
            batch = x;
           
            
        }

        public void draw()
        {
            if (texture != null)
                batch.Draw(texture, position);
        }

        public void reset() {
            position = new Vector2(height / 3 * 2, width / 2);
            Random rand = new Random();
            int x = rand.Next(3, 5);
            int ydir = rand.Next(0, 1);
            int yspeed = rand.Next(1, 5);
            if (ydir == 0)
            {
                ydir -= 1;
            }

            yspeed = yspeed * ydir;
            speed = new Vector2(x, yspeed);
            bottom = (int)position.Y + 3;
            right = (int)position.X + 3;

        }
    }
}