﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class BackgroundObj
    {
        
        private const string assetName = "board";
        private Texture2D texture;
        private SpriteBatch batch;
        private int width;

        public BackgroundObj(int width1) {
            width = width1;
        }

        public string getAssetName()
        {
            return assetName;
        }

        public void setSprite(Texture2D x)
        {
            texture = x;
        }

        public Texture2D getSprite()
        {
            return texture;
        }

        public void setSpriteBatch(SpriteBatch x)
        {
            batch = x;
        }

        public void draw()
        {
            if (texture != null)
                batch.Draw(texture, destinationRectangle: new Rectangle(0, 0, width, 64));
        }
    }
}