﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    /*
    ///This is the class used for handling the paddles/bars of the game of Pong
    ///
    ///
    */
     public class Bar
    {

        public Vector2 position;
        private const string assetName = "bar";
        private Texture2D texture;
        private SpriteBatch batch;
        private int height; // height of screen
        private bool isPlayer;

        public Bar(bool isPlay, int screenWidth, int screenHeight, int location) {

            position = new Vector2((screenWidth / 8) + (location * screenWidth / 8 * 6), screenHeight / 2);
            height = screenHeight;
            isPlayer = isPlay;
        }

        public bool isHuman() {
            return isPlayer;
        }

        public string getAssetName() {
            return assetName;
        }

        public void setSprite(Texture2D x) {
            texture = x;
        }

        public Texture2D getSprite() {
            return texture;
        }

        public void setSpriteBatch(SpriteBatch x) {
            batch = x;
        }

        public void reset() {
            position.Y = height / 2;
        }

        public void draw() {
            if (texture != null)
            batch.Draw(texture, position);
        }
        


        
    }
}