﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class BallManager
    {
        private int limit;
        private int height;
        private int width;
        
         
        public BallManager(int height1, int width1) {
            limit = 64; // where is the top
            height = height1;
            width = width1;
        }


        public void manage(Ball ball)
        {
            if (ball.position.Y < limit && ball.speed.Y < 0)
            {
                ball.speed.Y = (ball.speed.Y - 1) * -1; //faster on hit of sides
            }
            if (ball.bottom > height - 5 && ball.speed.Y > 0)
            {
                ball.speed.Y = (ball.speed.Y + 1) * -1;
            }
            ball.position.X += ball.speed.X * 2;
            ball.position.Y += ball.speed.Y / 2;
            ball.bottom = (int) ball.position.Y + ball.getSprite().Height;
            ball.right = (int) ball.position.X + ball.getSprite().Width;


            if (ball.position.X < 0 || ball.position.X > width)
            {
                ball.speed.X = 0;
                ball.speed.Y = 0;    
            }

        }
    }
}