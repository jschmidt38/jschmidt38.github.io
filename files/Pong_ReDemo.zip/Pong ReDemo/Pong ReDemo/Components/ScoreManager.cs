﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class ScoreManager
    {
        private SpriteFont font;
        private SpriteBatch batch;
        private Vector2 position;
        private const string assetName = "font";
        private int height;
        private int width;

        bool scoreAvailable;
        int scoreP1;
        int scoreP2; 
        public ScoreManager(bool on, int height1, int width1) {
            scoreAvailable = on;
            scoreP1 = 0;
            scoreP2 = 0;
            height = height1;
            width = width1;
            position = new Vector2((float)(width / 2) - 50,35);

        }

        public void manage(Ball ball)
        {
            if (scoreAvailable)
            {
                if (ball.position.X < 10) //scored against player
                {
                    scoreP2++;
                }
                else {
                    scoreP1++;
                }
                scoreAvailable = false;
            }
        }
        public void reset() {
            scoreAvailable = true;
        }
        public string getAssetName()
        {
            return assetName;
        }

        public void setSpriteFont(SpriteFont x)
        {
            font = x;
        }

        public SpriteFont getSprite()
        {
            return font;
        }

        public void setSpriteBatch(SpriteBatch x)
        {
            batch = x;

        }
        public bool gameActive() {
            return scoreAvailable;
        }

        public void draw()
        {
            if (font != null)
                batch.DrawString(font, "Score " + scoreP1 + " to " + scoreP2,position, Color.White);
        }
    }
}