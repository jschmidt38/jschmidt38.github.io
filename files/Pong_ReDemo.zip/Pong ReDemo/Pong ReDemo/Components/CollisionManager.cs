﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Pong_ReDemo.Components
{
    public class CollisionManager
    {
        private int margin;
        

        public CollisionManager() {
            margin = 10;
        }

        public void manage(Bar player, Bar computer, Ball ball)
        {
            //collision on the left
            int ballLeft = (int) ball.position.X;
            int ballTop = (int)ball.position.Y;
            int ballBottom = ball.bottom;
            int ballRight = ball.right;

            int playTop = (int) player.position.Y;
            int playBot = (int) player.position.Y + player.getSprite().Height;
            int playCenter = (int)player.position.X + player.getSprite().Width / 2; //actually  center of the paddle

            int compTop = (int)computer.position.Y;
            int compBot = (int)computer.position.Y + computer.getSprite().Height;
            int compCenter = (int)computer.position.X + computer.getSprite().Width / 2; //center of the paddle
            //hit on player
            if (ballLeft - playCenter < margin && ballLeft - playCenter > -1 && ball.speed.X < 0)
            {
                if (ballBottom >= playTop && ballTop <= playBot)
                {
                    ball.speed.X = -1 * ball.speed.X ;
                    ball.position.X = playCenter + player.getSprite().Width / 2;
                    ball.right = (int)ball.position.X + ball.getSprite().Width;
                }
            }

            //hit on comp
            if (ballRight - compCenter < margin && ballRight - compCenter > -1 && ball.speed.X > 0)
            {

                if (ballBottom >= compTop && ballTop <= compBot)
                {
                    ball.speed.X = -1 * ball.speed.X ;
                    ball.position.X = compCenter - (ball.getSprite().Width  / 2) - computer.getSprite().Width/2;
                    ball.right = (int)ball.position.X + ball.getSprite().Width;
                }
            }




        }
    }
}